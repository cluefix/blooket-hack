<h1 align="center">Blooket Hack</h1>
<h3 align="center">One of the best Blooket hacks.</h3>
<h2 align="center">Discord Support Server: https://discord.gg/abqMVbDanB</h2>

#### Made by rxzyx (rzx). This is purley for education purposes.
- 📫 Have a problem? **Just write an issue and I will do my best to respond.**

## How To Use:

- Simply open the file that sounds more interesting, click the "Raw" button, then copy the code and paste it into the chrome console when you're on blooket.

## Features:
- Default Scripts:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default%20Scripts/Add%20Tokens.js">Add Tokens</a> - Add the maximum XP and Tokens availible for the day.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default%20Scripts/Manipulate%20Plus.js">Manipulate Plus</a> - Make yourself a Plus Flex user! This means you can play modes that are only availible to plus users!
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default%20Scripts/All%20Answers%20Correct.js">All Answers Correct</a> - Get all the answers correct no matter what.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default%20Scripts/Host/End%20Game.js">End Game</a> - End the game. (Host)
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default%20Scripts/Flood%20Game.js">Flood Game</a> - Flood the game that you are in.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default%20Scripts/Host/Kick%20All.js">Kick All</a> - Kick Every Player In The Game. (Host)
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default%20Scripts/Host/Remove%20Player.js">Remove Player</a> - Remove a specific player from a game. (Host)
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default%20Scripts/Anti-Ban.js">Anti-Ban</a> - Prevent your account from being suspended. If you don't want to run this every time, you can use the <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default%20Scripts/Tampermonkey/Anti-Ban.js">Tampermonkey Version</a>.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default%20Scripts/Select%20Any%20Blook.js">Select Any Blook</a> - Select any blook that you want before the game starts! Automated by <a href="https://github.com/notzastix">@notzastix</a> on GitHub!
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Default%20Scripts/Get%20Answer%20Points.js">Get Answer Points</a> - Get however much of correct answers in the final score you want.
- Deceptive Dinos:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Deceptive%20Dinos/Fossil%20Hack.js">Fossil Hack</a> - Get however many Fossils you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Deceptive%20Dinos/Fossil%20Multiplier.js">Fossil Multiplier</a> - Set the fossil multiplier to anything.
- Gold Quest:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Gold%20Quest/Chest%20ESP.js">Chest ESP</a> - See Through Chests in Gold Quest.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Gold%20Quest/Get%20Gold.js">Get Gold</a> - Set the gold you have in gold quest to anything you want.
- Crypto Hack:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Crypto%20Hack/Auto%20Input%20Password.js">Auto Input Password</a> - Guess the password automatically once the password choices are shown.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Crypto%20Hack/Get%20Crypto.js">Get Crypto</a> - Set the crypto you have in crypto hack to anything you want.
- Fishing Frenzy:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Fishing%20Frenzy/Get%20Weight.js">Get Weight</a> - Set the weight to anything you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Fishing%20Frenzy/Set%20Frenzy%20Mode.js">Set Frenzy Mode</a> - Set the mode to frenzy.
- Tower Defense:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower%20Defense/Clear%20Enemies.js">Clear Enemies</a> - Clear the enemies on the screen.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower%20Defense/Get%20Damage.js">Get Damage</a> - Set the damage you have to anything you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower%20Defense/Get%20Tokens.js">Get Tokens</a> - Set the tokens you have to anything you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower%20Defense/Overpowered%20Towers.js">Overpowered Tokens</a> - Make the towers you place and have overpowered.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower%20Defense/Place%20Blooks%20Anywhere.js">Place Blooks Anywhere</a> - Place the blooks anywhere you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower%20Defense/Set%20Round.js">Set Round</a> - Set the round to anything you want.
- Cafe:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Cafe/Get%20Cash.js">Get Cash</a> - Set the cash you have in cafe mode to anything you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Cafe/Max%20Level%20Items.js">Max Level Items</a> - Set the items you have to the maximum level.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Cafe/Stock%20Unlimited%20Food.js">Stock Unlimited Food</a> - This will stock unlimited food in the cafe mode.
- Factory:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Factory/Add%20Cash.js">Add Cash</a> - Set the cash you have in factory mode to anything you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Factory/Add%20Mega%20Bot.js">Add Mega Bot</a> - Get however many mega bots you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Factory/Clear%20Ads%20Forever.js">Clear Ads Forever</a> - This will clear all the all the ads throught the game.
- Race:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Race/Instant%20Win.js">Instant Win</a> - Instantly win the race! (Once the hack is pasted and entered into the console then get a answer correct to win the game.)
- Tower of Doom:
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower%20Of%20Doom/Bad%20Enemy.js">Bad Enemy</a> - Make the enemy have really bad stats.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower%20Of%20Doom/Get%20Coins.js">Get Coins</a> - Set the coins you have to anything you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower%20Of%20Doom/Health%20Hack.js">Health Hack</a> - Set your health to anything you want.
    - <a href="https://github.com/rxzyx/Blooket-Hacks/blob/main/Tower%20Of%20Doom/Max%20Stats.js">Max Stats</a> - Make your blook overpowered.


#### I am not responsible for your actions with these cheats.

<h3 align="left">Made With JavaScript:</h3>
<p align="left"> <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> </p>

#### Copyright &copy; 2022 rzx.
